﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Web;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
namespace Eofficeservice
{
    class XmlR
    {
        public string Url;
        public struct ItemXml
        {
            public string name;
            public string created;
            public string des;
        }
        public string Content = "";
        public ItemXml[] arrItem = null;
        public int Length = 0;
        public XmlR(string url)
        {
            this.Url = url;
            arrItem = new ItemXml[1000];
            Length = 0;
            Content = "";
            Content = getContent(url);
            Content = getInfo(Content);
            //getAllItem(url);
        }
        public string getInfo(string content) {
            //content = content.ToLower();
            Regex titRegex;
            Match titm;
            titRegex = new Regex("<span id=\"lblInfo\">(.*?)</span>", RegexOptions.IgnoreCase);
                titm = titRegex.Match(content);
                if (titm.Success)
                {
                    //content = titm.Value;
                    //titRegex = new Regex("content=\"(.*?)\"", RegexOptions.IgnoreCase);
                    //titm = titRegex.Match(content);
                    return titm.Value.Replace("<span id=\"lblInfo\">", "").Replace("</span>", "");
                }
                return content;
        }
        public void Clear()
        {
            arrItem = null;
            Length = 0;
        }
        private string removeSpecialChar(string input)
        {
            input = input.Replace(":", "").Replace(",", "").Replace("_", "").Replace("'", "").Replace("\"", "").Replace(";", "");
            return input;
        }
        //getCOntent
        public static String getContent(String url)
        {
            String htmlCode = "";
            Random r = new Random();
            string[] myAngent = {"Mozilla/2.2",
                       "Mozilla/2.0b4",
                       "Mozilla/1.7.3",
                       "Namoroka/3.6.6pre",
                       "Netscape/9.1.0285",
                       "Netscape/9.0RC1",
                       "Opera/12.14",
                       "Chrome/32.0.1667.0",
                       "Chrome/32.0.1664.3",
                       "Chrome/28.0.1467.0",
                       "Chrome/28.0.1467.0",
                       "Chrome/23.0.1271.6",
                       "AOL/9.7"};
            try
            {
                bool conti = true;
                byte stry = 0;
                WebResponse myResponse;
                StreamReader sr;
                do
                {
                    try
                    {
                        conti = false;
                        HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(url);
                        myRequest.Method = "GET";
                        myRequest.Timeout = 15000;
                        myRequest.UserAgent = myAngent[r.Next(0, myAngent.Length)];
                        myResponse = myRequest.GetResponse();
                        sr = new StreamReader(myResponse.GetResponseStream(), System.Text.Encoding.UTF8);
                        htmlCode = sr.ReadToEnd();
                        sr.Close();
                        myResponse.Close();

                    }
                    catch (Exception err1)
                    {
                        conti = true;
                        stry++;
                    }
                } while (conti && stry < 3);
            }
            catch (Exception err)
            {
                return "";
            }

            return htmlCode;
        }
        private void getAllItem(string Url)
        {
            WebClient wc = new WebClient();
            string content = wc.DownloadString(Url); 
            //Fetch the subscribed RSS Feed
            XmlDocument RSSXml = new XmlDocument();
            RSSXml.LoadXml(content);

            XmlNodeList RSSNodeList = RSSXml.SelectNodes("data/Items");
            Length = 0;

            StringBuilder sb = new StringBuilder();

            foreach (XmlNode RSSNode in RSSNodeList)
            {
                XmlNode RSSSubNode;
                RSSSubNode = RSSNode.SelectSingleNode("realname");
                string rname = RSSSubNode != null ? RSSSubNode.InnerText : "";

                RSSSubNode = RSSNode.SelectSingleNode("created");
                string created = RSSSubNode != null ? RSSSubNode.InnerText : "";

                RSSSubNode = RSSNode.SelectSingleNode("description");
                string des = RSSSubNode != null ? RSSSubNode.InnerText : "";
                if (!rname.Trim().Equals(""))
                {
                    arrItem[Length].name = removeSpecialChar(rname);
                    arrItem[Length].created = created;
                    arrItem[Length].des = des;
                    Length++;
                }
            }
        }//void
    }//class
}
