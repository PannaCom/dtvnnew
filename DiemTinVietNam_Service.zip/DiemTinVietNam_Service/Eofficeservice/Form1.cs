﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Text.RegularExpressions;  
using Microsoft.Win32; 
namespace Eofficeservice
{
    public partial class Form1 : Form
    {
        private NotifyIcon  trayIcon;
        private ContextMenu trayMenu;
        RegistryKey rkApp = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
        private string Main_Key = "diemtinvietnam.vn";
        public Form1()
        {
            InitializeComponent();
            // Check to see the current state (running at startup or not)
            if (rkApp.GetValue(Main_Key) == null)
            {
                // The value doesn't exist, the application is not set to run at startup
                chkRun.Checked = false;
            }
            else
            {
                // The value exists, the application is set to run at startup
                chkRun.Checked = true;
                getConfig();
            }
        }
        private void getConfig()
        {
            RegistryKey sk1 = rkApp.OpenSubKey("user");
            if (sk1 != null)
            {
                txtUser.Text = sk1.GetValue("user").ToString();
                sk1 = rkApp.OpenSubKey("pass");
                txtPass.Text = sk1.GetValue("pass").ToString();
                sk1 = rkApp.OpenSubKey("time");
                txtTime.Text = sk1.GetValue("time").ToString();
                sk1 = rkApp.OpenSubKey("domain");
                txtDomain.Text = sk1.GetValue("domain").ToString();
            }

        }
        Thread theRun = null;
        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false;
        }
        private string toStringSys()
        {
            return txtUser.Text.Trim() + "|" + txtPass.Text.Trim() + "|" + txtTime.Text.Trim() + "|" + txtDomain.Text.Trim();            
        }
        private void runAll()
        {
            string domain = txtDomain.Text.Trim();
            XmlR R=new XmlR(domain);
            string content = R.Content;
            //String content=R.get
            //for (int i = 0; i < R.Length; i++)
            //if (R.arrItem[i].name!=null && !R.arrItem[i].name.Equals(""))
            //{
            trayIcon.ShowBalloonTip(2000, Main_Key, "Gọi thành công:" + content + " \r\nMở :" + domain, ToolTipIcon.Info);  
            //}
        }
        private void OnExit(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void OnShow(object sender, EventArgs e)
        {
            this.Visible = true; 
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (theRun.IsAlive)
            {
                theRun.Abort();                
            }
            theRun = new Thread(new ThreadStart(runAll));
            theRun.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtDomain.Text = "http://diemtinvietnam.net/adminYouKnow.aspx";
            if (txtUser.Text.Trim().Equals("") || txtPass.Text.Trim().Equals("") || txtTime.Text.Trim().Equals(""))
            {
                MessageBox.Show("Nhập pass và user, thời gian nhắc");
                return;
            }
            // Create a simple tray menu with only one item.
            trayMenu = new ContextMenu();
            trayMenu.MenuItems.Add("Thoát", OnExit);
            trayMenu.MenuItems.Add("Hiển thị", OnShow);
            // Create a tray icon. In this example we use a
            // standard system icon for simplicity, but you
            // can of course use your own custom icon too.
            trayIcon = new NotifyIcon();
            trayIcon.Text = Main_Key;
            trayIcon.Icon = new Icon(SystemIcons.Application, 40, 40);

            // Add menu to tray icon and show it.
            trayIcon.ContextMenu = trayMenu;
            trayIcon.Visible = true;
            trayIcon.ShowBalloonTip(2000, Main_Key, "Hệ thống nhắc nhở crawl", ToolTipIcon.Info);
            this.Visible = false;
            if (theRun != null && theRun.IsAlive) theRun.Abort();
            theRun = new Thread(new ThreadStart(runAll));
            theRun.Start();
            timer1.Interval = int.Parse(txtTime.Text) * 60000;
            timer1.Start();
            if (chkRun.Checked)
            {
                // Add the value in the registry so that the application runs at startup
                rkApp.SetValue(Main_Key, Application.ExecutablePath.ToString());

                RegistryKey sk1 = rkApp.CreateSubKey("user");
                sk1.SetValue("user", txtUser.Text.Trim());
                sk1 = rkApp.CreateSubKey("pass");
                sk1.SetValue("pass", txtPass.Text.Trim());
                sk1 = rkApp.CreateSubKey("time");
                sk1.SetValue("time", txtTime.Text.Trim());
                sk1 = rkApp.CreateSubKey("domain");
                sk1.SetValue("domain", txtDomain.Text.Trim());
            }
            else
            {
                // Remove the value from the registry so that the application doesn't start
                rkApp.DeleteValue(Main_Key, false);
            }
        }

        
    }
}
